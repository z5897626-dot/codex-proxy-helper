using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Security;
using System.Net.Sockets;
using System.Security.Authentication;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

internal static class LaunchCore
{
    internal static readonly string Proxy = "http://127.0.0.1:7890";
    internal static string FindApp()
    {
        string known = @"C:\Program Files\WindowsApps\OpenAI.Codex_26.1013.4894.0_x64__2p2nqsd0c76g0\app\ChatGPT.exe";
        try
        {
            foreach (var p in Process.GetProcessesByName("ChatGPT"))
                using (p) { try { string path = p.MainModule.FileName; if (path.IndexOf("OpenAI.Codex_", StringComparison.OrdinalIgnoreCase) >= 0 && File.Exists(path)) return path; } catch { } }
        } catch { }
        if (File.Exists(known)) return known;
        string apps = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.ProgramFiles), "WindowsApps");
        try
        {
            foreach (string dir in Directory.GetDirectories(apps, "OpenAI.Codex_*_x64__2p2nqsd0c76g0").OrderByDescending(x => x))
            { string path = Path.Combine(dir, "app", "ChatGPT.exe"); if (File.Exists(path)) return path; }
        } catch { }
        throw new Exception("找不到已安装的 ChatGPT / Codex。请先正常打开客户端，再运行此启动器。");
    }
    internal static List<int> Running()
    {
        var ids = new List<int>();
        foreach (string name in new[] { "ChatGPT", "codex" })
            foreach (var p in Process.GetProcessesByName(name))
                using (p)
                {
                    try
                    {
                        string path = p.MainModule.FileName;
                        if (path.IndexOf("OpenAI.Codex_", StringComparison.OrdinalIgnoreCase) >= 0 ||
                            (name == "codex" && path.IndexOf(@"OpenAI\Codex\bin\", StringComparison.OrdinalIgnoreCase) >= 0)) ids.Add(p.Id);
                    }
                    catch { if (!p.HasExited) ids.Add(p.Id); }
                }
        return ids;
    }
    internal static ProcessStartInfo StartInfo(string path)
    {
        var info = new ProcessStartInfo(path) { UseShellExecute = false, WorkingDirectory = Path.GetDirectoryName(path) };
        foreach (string key in new[] { "HTTP_PROXY", "HTTPS_PROXY", "WS_PROXY", "WSS_PROXY" }) info.EnvironmentVariables[key] = Proxy;
        var no = (info.EnvironmentVariables["NO_PROXY"] ?? "").Split(',').Select(x => x.Trim()).Where(x => x.Length > 0).ToList();
        foreach (string host in new[] { "localhost", "127.0.0.1", "::1" }) if (!no.Contains(host, StringComparer.OrdinalIgnoreCase)) no.Add(host);
        info.EnvironmentVariables["NO_PROXY"] = String.Join(",", no);
        return info;
    }
    internal static string Probe()
    {
        using (var tcp = new TcpClient())
        {
            IAsyncResult pending = tcp.BeginConnect("127.0.0.1", 7890, null, null);
            using (var handle = pending.AsyncWaitHandle) if (!handle.WaitOne(2500)) throw new Exception("无法连接 Clash 的 7890 端口，请先启动 Clash。");
            tcp.EndConnect(pending); tcp.ReceiveTimeout = 8000; tcp.SendTimeout = 4000;
            var stream = tcp.GetStream();
            byte[] b = Encoding.ASCII.GetBytes("CONNECT chatgpt.com:443 HTTP/1.1\r\nHost: chatgpt.com:443\r\n\r\n"); stream.Write(b, 0, b.Length);
            var reply = new List<byte>();
            while (reply.Count < 16384)
            {
                int c = stream.ReadByte(); if (c < 0) break; reply.Add((byte)c);
                int n = reply.Count; if (n >= 4 && reply[n-4] == 13 && reply[n-3] == 10 && reply[n-2] == 13 && reply[n-1] == 10) break;
            }
            string header = Encoding.ASCII.GetString(reply.ToArray());
            if (!(header.StartsWith("HTTP/1.1 200 ") || header.StartsWith("HTTP/1.0 200 "))) throw new Exception("代理没有成功建立隧道，请检查 Clash 线路。");
            using (var tls = new SslStream(stream, false))
            {
                tls.ReadTimeout = 8000; tls.WriteTimeout = 4000;
                tls.AuthenticateAsClient("chatgpt.com", null, SslProtocols.Tls12, true);
                return "Clash HTTP 隧道与 chatgpt.com TLS 证书验证通过。";
            }
        }
    }
}

internal class Launcher : Form
{
    TextBox log = new TextBox(); Button start = new Button(); Button cancel = new Button();
    System.Windows.Forms.Timer timer = new System.Windows.Forms.Timer();
    bool waiting, probing; int clearTicks; string app;
    internal Launcher()
    {
        Text = "Codex 代理修复启动器 · 第二版"; ClientSize = new Size(710, 430); StartPosition = FormStartPosition.CenterScreen;
        Font = new Font("Microsoft YaHei UI", 10); FormBorderStyle = FormBorderStyle.FixedDialog; MaximizeBox = false;
        Controls.Add(new Label { Left=20, Top=18, Width=670, Height=98, Text="已针对这台电脑配置 Clash：127.0.0.1:7890。\r\n这个版本会给客户端及其子进程明确传入 HTTP、HTTPS、WS、WSS 代理。\r\n使用时保持 Clash 开启。无需修改系统用户环境变量。\r\n请先保存其他聊天中的工作，再从托盘或菜单完全退出 ChatGPT / Codex。" });
        start.SetBounds(20, 125, 320, 38); start.Text="检查代理，等待旧进程退出后启动"; start.Click += async (s,e) => await Prepare(); Controls.Add(start);
        cancel.SetBounds(355, 125, 170, 38); cancel.Text="取消等待"; cancel.Enabled=false; cancel.Click += (s,e) => { waiting=false; timer.Stop(); start.Enabled=true; cancel.Enabled=false; Say("已取消，没有关闭或启动客户端。"); }; Controls.Add(cancel);
        log.SetBounds(20, 182, 670, 180); log.Multiline=true; log.ReadOnly=true; log.ScrollBars=ScrollBars.Vertical; Controls.Add(log);
        Controls.Add(new Label { Left=20, Top=377, Width=670, Height=45, Text="本工具不会强制结束聊天，也不会自动重启电脑。\r\n启动后请新建聊天测试；原快捷方式启动的旧进程无法被此工具修改环境。" });
        timer.Interval=1500; timer.Tick += async (s,e) => await Tick();
        Say("尚未执行任何操作。点击上方按钮后，再完全退出客户端；此窗口保持打开。");
    }
    void Say(string s) { log.AppendText(DateTime.Now.ToString("HH:mm:ss")+"  "+s+"\r\n"); }
    async Task Prepare()
    {
        start.Enabled=false; probing=true;
        try
        {
            app=LaunchCore.FindApp(); Say("正在验证 Clash 代理和 TLS 连接…");
            string result=await Task.Run(() => LaunchCore.Probe()); Say(result);
            waiting=true; clearTicks=0; cancel.Enabled=true;
            if (LaunchCore.Running().Count>0) Say("仍检测到旧客户端。请保存工作，并从托盘或菜单完全退出；关闭窗口可能只会最小化。");
            else Say("未检测到旧客户端，即将使用明确的代理环境启动。");
            timer.Start();
        }
        catch(Exception ex) { Say("未启动："+ex.Message); start.Enabled=true; }
        finally { probing=false; }
    }
    async Task Tick()
    {
        if (!waiting || probing) return;
        if (LaunchCore.Running().Count>0) { clearTicks=0; return; }
        if (++clearTicks<2) return;
        timer.Stop(); waiting=false; cancel.Enabled=false; probing=true;
        try
        {
            Say("旧进程已退出，重新确认代理连接…"); await Task.Run(() => LaunchCore.Probe());
            if (LaunchCore.Running().Count>0) { Say("客户端被其他方式重新打开，请完全退出后重试。"); return; }
            using (Process child=Process.Start(LaunchCore.StartInfo(app)))
            {
                if (child==null) throw new Exception("系统未返回启动进程。");
                Say("已启动客户端，代理环境已传入。请在新聊天中测试是否还重连。");
            }
        }
        catch(Exception ex) { Say("启动失败："+ex.Message); }
        finally { probing=false; start.Enabled=true; }
    }
    protected override void OnFormClosing(FormClosingEventArgs e)
    {
        if(probing) { e.Cancel=true; Say("正在检查连接，请稍等几秒。"); }
        else { waiting=false; timer.Stop(); }
        base.OnFormClosing(e);
    }
}

internal static class Entry
{
    [STAThread] static int Main(string[] args)
    {
        if(args.Length>0 && args[0]=="--check-child-env")
        {
            foreach(string k in new[]{"HTTP_PROXY","HTTPS_PROXY","WS_PROXY","WSS_PROXY"})
                if(Environment.GetEnvironmentVariable(k)!=LaunchCore.Proxy) return 8;
            return 0;
        }
        if(args.Length>0 && args[0]=="--self-test")
        {
            try
            {
                var info=LaunchCore.StartInfo(LaunchCore.FindApp());
                foreach(string k in new[]{"HTTP_PROXY","HTTPS_PROXY","WS_PROXY","WSS_PROXY"}) if(info.EnvironmentVariables[k]!=LaunchCore.Proxy) return 2;
                if(info.UseShellExecute || !info.EnvironmentVariables["NO_PROXY"].Contains("127.0.0.1")) return 3;
                var childInfo=LaunchCore.StartInfo(System.Reflection.Assembly.GetExecutingAssembly().Location);
                childInfo.Arguments="--check-child-env";
                using(var child=Process.Start(childInfo))
                    if(child==null || !child.WaitForExit(5000) || child.ExitCode!=0) return 4;
                if(args.Contains("--network")) LaunchCore.Probe();
                return 0;
            }
            catch { return 1; }
        }
        Application.EnableVisualStyles(); Application.SetCompatibleTextRenderingDefault(false); Application.Run(new Launcher()); return 0;
    }
}
